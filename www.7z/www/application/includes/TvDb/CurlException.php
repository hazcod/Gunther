<?php

namespace Moinax\TvDb;


class CurlException extends \Exception
{

}