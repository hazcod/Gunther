<meta charset="utf-8">
<title><?php echo $this->getPagetitle(); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="<?php echo URL::base_uri(); ?>css/bootstrap.css" rel="stylesheet">
<link href="<?php echo URL::base_uri(); ?>css/owl.carousel.css" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
<link href="<?php echo URL::base_uri(); ?>css/video-js.min.css" rel="stylesheet">
<link href="<?php echo URL::base_uri(); ?>css/custom.css" rel="stylesheet">
<!--[if lt IE 9]>
	<script src="<?php echo URL::base_uri(); ?>js/html5shiv.js"></script>
	<script src="<?php echo URL::base_uri(); ?>js/respond.min.js"></script>
<![endif]-->

